import { NavLink, Route, Routes } from "react-router-dom";
import Dashboard from "./pages/Dashboard.jsx";
import Tasks from "./pages/Tasks.jsx";
import Kanban from "./pages/Kanban.jsx";
import Calendar from "./pages/Calendar.jsx";
import Analytics from "./pages/Analytics.jsx";
import Settings from "./pages/Settings.jsx";

const links = [
  ["/", "Dashboard"],
  ["/tasks", "My Tasks"],
  ["/kanban", "Kanban"],
  ["/calendar", "Calendar"],
  ["/analytics", "Analytics"],
  ["/settings", "Settings"],
];

export default function App() {
  return (
    <div className="layout">
      <nav className="sidebar">
        <h1 className="logo">✓ TaskFlow</h1>
        {links.map(([to, label]) => (
          <NavLink key={to} to={to} end={to === "/"} className="navlink">
            {label}
          </NavLink>
        ))}
      </nav>
      <main className="content">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/kanban" element={<Kanban />} />
          <Route path="/calendar" element={<Calendar />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </main>
    </div>
  );
}
