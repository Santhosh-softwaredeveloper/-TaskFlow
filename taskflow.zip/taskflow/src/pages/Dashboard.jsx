import { useTasks } from "../context/TaskContext.jsx";

export default function Dashboard() {
  const { tasks, settings } = useTasks();
  const done = tasks.filter((t) => t.status === "done").length;
  const stats = [
    ["Total Tasks", tasks.length],
    ["Completed", done],
    ["Pending", tasks.length - done],
  ];
  const upcoming = tasks
    .filter((t) => t.status !== "done" && t.due)
    .sort((a, b) => a.due.localeCompare(b.due))
    .slice(0, 5);

  return (
    <>
      <h2>Welcome back, {settings.name} 👋</h2>
      <div className="grid">
        {stats.map(([label, n]) => (
          <div className="card stat" key={label}>
            <span>{label}</span>
            <strong>{n}</strong>
          </div>
        ))}
      </div>
      <h3>Upcoming deadlines</h3>
      <div className="card">
        {upcoming.length === 0 && <p className="muted">Nothing due. Add tasks with deadlines!</p>}
        {upcoming.map((t) => (
          <div className="item" key={t.id}>
            <span>{t.title}</span>
            <span className="muted">{t.due}</span>
          </div>
        ))}
      </div>
    </>
  );
}
