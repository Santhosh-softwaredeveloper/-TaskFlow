import { useState } from "react";
import { useTasks } from "../context/TaskContext.jsx";

const pad = (n) => String(n).padStart(2, "0");

export default function Calendar() {
  const { tasks } = useTasks();
  const [cursor, setCursor] = useState(() => new Date());
  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const offset = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const cells = [...Array(offset).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  const move = (d) => setCursor(new Date(year, month + d, 1));

  return (
    <>
      <h2>Calendar</h2>
      <div className="row">
        <button className="btn ghost" onClick={() => move(-1)}>←</button>
        <strong>{cursor.toLocaleString("default", { month: "long", year: "numeric" })}</strong>
        <button className="btn ghost" onClick={() => move(1)}>→</button>
      </div>
      <div className="cal">
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
          <div key={d} className="calhead">{d}</div>
        ))}
        {cells.map((d, i) => {
          const key = d && `${year}-${pad(month + 1)}-${pad(d)}`;
          const due = d ? tasks.filter((t) => t.due === key) : [];
          return (
            <div key={i} className={`day ${d ? "" : "empty"}`}>
              {d && <span className="num">{d}</span>}
              {due.map((t) => (
                <div key={t.id} className={`chip ${t.status}`} title={t.title}>{t.title}</div>
              ))}
            </div>
          );
        })}
      </div>
    </>
  );
}
