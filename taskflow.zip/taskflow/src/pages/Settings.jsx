import { useTasks } from "../context/TaskContext.jsx";

export default function Settings() {
  const { settings, setSettings, clearAll } = useTasks();

  return (
    <>
      <h2>Settings</h2>
      <div className="card form">
        <label>
          Profile name
          <input value={settings.name} onChange={(e) => setSettings({ ...settings, name: e.target.value })} />
        </label>
        <label>
          Theme: <strong>{settings.theme}</strong>
        </label>
        <button
          className="btn"
          onClick={() => setSettings({ ...settings, theme: settings.theme === "light" ? "dark" : "light" })}
        >
          Switch to {settings.theme === "light" ? "dark" : "light"} mode
        </button>
        <button
          className="btn danger"
          onClick={() => window.confirm("Delete all tasks?") && clearAll()}
        >
          Clear all tasks
        </button>
      </div>
    </>
  );
}
