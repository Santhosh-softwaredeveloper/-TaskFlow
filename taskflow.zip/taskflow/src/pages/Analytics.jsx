import { useEffect, useRef } from "react";
import Chart from "chart.js/auto";
import { useTasks } from "../context/TaskContext.jsx";

export default function Analytics() {
  const { tasks } = useTasks();
  const statusRef = useRef(null);
  const priorityRef = useRef(null);

  useEffect(() => {
    const count = (key, v) => tasks.filter((t) => t[key] === v).length;

    const statusChart = new Chart(statusRef.current, {
      type: "doughnut",
      data: {
        labels: ["To Do", "In Progress", "Completed"],
        datasets: [{
          data: [count("status", "todo"), count("status", "progress"), count("status", "done")],
          backgroundColor: ["#f59e0b", "#3b82f6", "#10b981"],
        }],
      },
    });

    const priorityChart = new Chart(priorityRef.current, {
      type: "bar",
      data: {
        labels: ["Low", "Medium", "High"],
        datasets: [{
          label: "Tasks by priority",
          data: [count("priority", "low"), count("priority", "medium"), count("priority", "high")],
          backgroundColor: "#6366f1",
        }],
      },
      options: { scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
    });

    return () => { statusChart.destroy(); priorityChart.destroy(); };
  }, [tasks]);

  const done = tasks.filter((t) => t.status === "done").length;
  const rate = tasks.length ? Math.round((done / tasks.length) * 100) : 0;

  return (
    <>
      <h2>Analytics</h2>
      <p>Completion rate: <strong>{rate}%</strong></p>
      <div className="grid">
        <div className="card"><canvas ref={statusRef} /></div>
        <div className="card"><canvas ref={priorityRef} /></div>
      </div>
    </>
  );
}
