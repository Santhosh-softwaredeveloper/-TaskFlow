import { useState } from "react";
import { useTasks } from "../context/TaskContext.jsx";
import TaskForm from "../components/TaskForm.jsx";

const labels = { todo: "To Do", progress: "In Progress", done: "Completed" };

export default function Tasks() {
  const { tasks, addTask, updateTask, deleteTask } = useTasks();
  const [editing, setEditing] = useState(null);
  const [filter, setFilter] = useState("all");

  const shown = filter === "all" ? tasks : tasks.filter((t) => t.status === filter);

  return (
    <>
      <h2>My Tasks</h2>
      <TaskForm onSave={addTask} />
      <div className="row filters">
        {["all", "todo", "progress", "done"].map((f) => (
          <button key={f} className={`btn ${filter === f ? "" : "ghost"}`} onClick={() => setFilter(f)}>
            {f === "all" ? "All" : labels[f]}
          </button>
        ))}
      </div>
      {shown.length === 0 && <p className="muted">No tasks here yet.</p>}
      {shown.map((t) =>
        editing === t.id ? (
          <TaskForm
            key={t.id}
            initial={t}
            onCancel={() => setEditing(null)}
            onSave={(data) => { updateTask(t.id, data); setEditing(null); }}
          />
        ) : (
          <div className="card item" key={t.id}>
            <div>
              <strong className={t.status === "done" ? "strike" : ""}>{t.title}</strong>
              <p className="muted">{t.description}</p>
              <span className={`tag ${t.priority}`}>{t.priority}</span>{" "}
              <span className="tag">{labels[t.status]}</span>{" "}
              {t.due && <span className="muted">📅 {t.due}</span>}
            </div>
            <div className="row">
              <button className="btn ghost" onClick={() => setEditing(t.id)}>Edit</button>
              <button className="btn danger" onClick={() => deleteTask(t.id)}>Delete</button>
            </div>
          </div>
        )
      )}
    </>
  );
}
