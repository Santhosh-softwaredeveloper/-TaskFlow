import { useTasks } from "../context/TaskContext.jsx";

const columns = [
  ["todo", "To Do"],
  ["progress", "In Progress"],
  ["done", "Completed"],
];

export default function Kanban() {
  const { tasks, updateTask } = useTasks();

  const onDrop = (e, status) => {
    const id = e.dataTransfer.getData("id");
    if (id) updateTask(id, { status });
  };

  return (
    <>
      <h2>Kanban Board</h2>
      <p className="muted">Drag cards between columns.</p>
      <div className="board">
        {columns.map(([status, title]) => (
          <div
            key={status}
            className="column"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => onDrop(e, status)}
          >
            <h3>{title} ({tasks.filter((t) => t.status === status).length})</h3>
            {tasks
              .filter((t) => t.status === status)
              .map((t) => (
                <div
                  key={t.id}
                  className="card kcard"
                  draggable
                  onDragStart={(e) => e.dataTransfer.setData("id", t.id)}
                >
                  <strong>{t.title}</strong>
                  <div>
                    <span className={`tag ${t.priority}`}>{t.priority}</span>{" "}
                    {t.due && <span className="muted">{t.due}</span>}
                  </div>
                </div>
              ))}
          </div>
        ))}
      </div>
    </>
  );
}
