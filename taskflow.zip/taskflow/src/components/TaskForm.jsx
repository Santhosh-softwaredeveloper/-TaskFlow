import { useState } from "react";

const empty = { title: "", description: "", due: "", priority: "medium", status: "todo" };

export default function TaskForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState(initial || empty);
  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = (e) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    onSave(form);
    if (!initial) setForm(empty);
  };

  return (
    <form className="card form" onSubmit={submit}>
      <input name="title" placeholder="Task title" value={form.title} onChange={change} required />
      <textarea name="description" placeholder="Description" value={form.description} onChange={change} />
      <div className="row">
        <input type="date" name="due" value={form.due} onChange={change} />
        <select name="priority" value={form.priority} onChange={change}>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <select name="status" value={form.status} onChange={change}>
          <option value="todo">To Do</option>
          <option value="progress">In Progress</option>
          <option value="done">Completed</option>
        </select>
      </div>
      <div className="row">
        <button className="btn" type="submit">{initial ? "Update" : "Add Task"}</button>
        {onCancel && <button type="button" className="btn ghost" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  );
}
