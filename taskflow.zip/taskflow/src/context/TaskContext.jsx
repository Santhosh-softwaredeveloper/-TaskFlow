import { createContext, useContext, useEffect, useState } from "react";

const TaskContext = createContext();
export const useTasks = () => useContext(TaskContext);

// Small hook: state that syncs to localStorage
function useLocalStorage(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);
  return [value, setValue];
}

export function TaskProvider({ children }) {
  const [tasks, setTasks] = useLocalStorage("taskflow-tasks", []);
  const [settings, setSettings] = useLocalStorage("taskflow-settings", {
    theme: "light",
    name: "Your Name",
  });

  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme;
  }, [settings.theme]);

  const addTask = (t) => setTasks((p) => [...p, { ...t, id: Date.now().toString() }]);
  const updateTask = (id, changes) =>
    setTasks((p) => p.map((t) => (t.id === id ? { ...t, ...changes } : t)));
  const deleteTask = (id) => setTasks((p) => p.filter((t) => t.id !== id));
  const clearAll = () => setTasks([]);

  return (
    <TaskContext.Provider
      value={{ tasks, addTask, updateTask, deleteTask, clearAll, settings, setSettings }}
    >
      {children}
    </TaskContext.Provider>
  );
}
