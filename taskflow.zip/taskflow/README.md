# TaskFlow
Run: `npm install` then `npm run dev` (open the URL Vite prints).
